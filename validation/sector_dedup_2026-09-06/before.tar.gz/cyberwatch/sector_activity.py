"""Contrat commun de preuve activité/victime, indépendant du transport LLM."""
from __future__ import annotations

import re

from .normalize import searchable

ACTIVITY_FIELDS = {"activity_description", "activity_sector_match"}
_ACTIVITY = re.compile(
    r"\b(?:specialis\w*|commercialis\w*|vend\w*|vente|boutique|negoce|"
    r"distribu\w*|fabric\w*|produi\w*|production|edite\w*|editeur|developp\w*|"
    r"formation|enseignement|teleconsult\w*|transports?|logistique|reexpedition|"
    r"expedition|livraison|restauration|restaurants?|repas|hebergement|hotell\w*|"
    r"logiciels?|applications?|cloud|stockage|chimie|batiment|second oeuvre|"
    r"agric\w*|horticulture|syndica\w*|represente|accompagne|"
    r"municipalite|organisme public|etablissement public|sante|foncier\w*|"
    r"gestion|assurance|banque|conseil|sport\w*|football)\b"
)
_THIRD_PARTY = re.compile(r"\b(?:prestataire|fournisseur|partenaire|client|filiale|sous traitant)\b")


def supported_activity(organisation: str, value: str, evidence: str) -> bool:
    from .source_facts import _activity_evidence_matches_organisation

    proof = searchable(evidence)
    org = searchable(organisation)
    if _THIRD_PARTY.search(proof[:max(0, proof.find(org))]):
        return False
    segments = re.split(r"(?<=[.!?;])\s+|\n+", evidence)
    if len(segments) > 1:
        return any(supported_activity(organisation, value, part) for part in segments if part.strip())
    body = proof.replace(org, "") if org else proof
    if re.search(r"\b(?:son|ses|le|un|du|d un) (?:prestataire|fournisseur|partenaire|client)\b", body):
        return False
    if re.search(r"\b(?:utilise|fait appel|client de|via)\b", body):
        return False
    return bool(value and _ACTIVITY.search(body)
                and _activity_evidence_matches_organisation(organisation, evidence))


def contextual_proof(organisation: str, evidence: str, context: str) -> str:
    """Étend la citation à sa phrase si la victime en est le sujet explicite."""
    org = searchable(organisation)
    needle = searchable(evidence)
    if not org or not needle:
        return ""
    for sentence in re.split(r"(?<=[.!?;])\s+|\n+", context):
        normalized = searchable(sentence)
        if needle not in normalized or len(sentence) > 300:
            continue
        start = normalized.find(org)
        if start < 0 or normalized[:start].strip() not in {
            "", "la", "le", "l", "societe", "entreprise",
            "une fuite de donnees visant", "une cyberattaque visant",
        }:
            continue
        if _THIRD_PARTY.search(normalized[start + len(org):]):
            continue
        if supported_activity(organisation, sentence, sentence):
            return sentence.strip()
    return ""


def activity_from_text(organisation: str, *texts: str) -> tuple[str, str]:
    for text in texts:
        for sentence in re.split(r"(?<=[.!?;])\s+|\n+", text or ""):
            proof = contextual_proof(organisation, sentence, sentence)
            if proof:
                return proof, proof
    return "", ""
