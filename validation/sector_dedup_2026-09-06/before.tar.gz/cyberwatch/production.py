"""Pilotage quotidien de la fiabilité, de la qualité et du coût produit."""

from __future__ import annotations

import datetime as dt
import json
from pathlib import Path

from . import config, duplicate_audit, store
from .model import Incident, Item
from .normalize import classify_location, classify_sector, classify_threat, looks_cyber

FRESHNESS_TARGET_HOURS = 36.0
SCHEDULED_SUCCESS_TARGET_PCT = 95.0
SECTOR_UNKNOWN_TARGET_PCT = 10.0
LOCATION_UNKNOWN_TARGET_PCT = 5.0
REQUIRED_CONSECUTIVE_SCHEDULED_SUCCESSES = 7
SCHEDULED_RELIABILITY_WINDOW = 30

BUSINESS_CORPUS_PATH = Path(__file__).resolve().parents[1] / "validation" / "business_corpus.json"
DEDUP_CORPUS_PATH = Path(__file__).resolve().parents[1] / "tests" / "fixtures" / "dedup_identity_cases.json"


def _pct(numerator: int, denominator: int) -> float:
    return round(100.0 * numerator / denominator, 2) if denominator else 0.0


def _float(value: object, default: float = 0.0) -> float:
    try:
        return float(str(value))
    except (TypeError, ValueError):
        return default


def _parse_datetime(value: str) -> dt.datetime | None:
    try:
        parsed = dt.datetime.fromisoformat(str(value or "").replace("Z", "+00:00"))
    except ValueError:
        return None
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=dt.UTC)
    return parsed


def load_business_corpus(path: Path | None = None) -> list[dict]:
    payload = json.loads((path or BUSINESS_CORPUS_PATH).read_text(encoding="utf-8"))
    cases = payload.get("cases", [])
    if not isinstance(cases, list) or not cases:
        raise ValueError("Le corpus métier doit contenir une liste non vide de cas.")
    return cases


def evaluate_business_corpus(cases: list[dict] | None = None) -> dict:
    """Évalue les règles déterministes sur un corpus versionné et sans réseau."""
    cases = cases or load_business_corpus()
    false_positives: list[str] = []
    false_negatives: list[str] = []
    classification_errors: list[str] = []
    negative_scope_cases = 0

    for case in cases:
        case_id = str(case.get("case_id") or "sans-id")
        kind = case.get("kind")
        if kind == "scope":
            expected = bool(case.get("expected_in_scope"))
            predicted = looks_cyber(case.get("text", ""))
            if not expected:
                negative_scope_cases += 1
            if predicted and not expected:
                false_positives.append(case_id)
            elif expected and not predicted:
                false_negatives.append(case_id)
            expected_threat = case.get("expected_threat")
            if expected_threat and classify_threat(case.get("text", "")) != expected_threat:
                classification_errors.append(case_id)
        elif kind == "location":
            predicted = classify_location(
                case.get("text", ""),
                given=case.get("given", ""),
                entity=case.get("entity", ""),
                default=case.get("default", ""),
            )
            if predicted != case.get("expected"):
                classification_errors.append(case_id)
        elif kind == "sector":
            predicted = classify_sector(
                case.get("organisation", ""),
                case.get("text", ""),
                given=case.get("given", ""),
            )
            if predicted != case.get("expected"):
                classification_errors.append(case_id)
        else:
            raise ValueError(f"Type de cas métier inconnu : {kind!r}")

    return {
        "cases": len(cases),
        "false_positives": len(false_positives),
        "false_positive_rate_pct": _pct(len(false_positives), negative_scope_cases),
        "false_negatives": len(false_negatives),
        "classification_errors": len(classification_errors),
        "failed_cases": sorted(false_positives + false_negatives + classification_errors),
        "passed": not (false_positives or false_negatives or classification_errors),
    }


def evaluate_dedup_corpus(path: Path | None = None) -> dict:
    payload = json.loads((path or DEDUP_CORPUS_PATH).read_text(encoding="utf-8"))
    return duplicate_audit.dedup_identity_benchmark(payload.get("cases", []))


def metric_row(
    *,
    run_id: str,
    as_of: str,
    trigger: str,
    overall_status: str,
    published: bool,
    items: list[Item],
    incidents: list[Incident],
    duration_seconds: float,
    requests: int,
    llm_calls: int,
    llm_cost_usd: float,
) -> dict:
    incident_count = len(incidents)
    sector_unknown = sum(i.Secteur == config.SECTOR_UNKNOWN for i in incidents)
    location_unknown = sum(i.Localisation == config.LOC_INCONNU for i in incidents)
    duplicate_pairs = len(duplicate_audit.find_audit_candidates(items))
    corpus = evaluate_business_corpus()
    dedup = evaluate_dedup_corpus()
    return {
        "Run_ID": run_id,
        "As_Of": as_of,
        "Trigger": trigger,
        "Overall_Status": overall_status,
        "Published": str(bool(published)).lower(),
        "Items_Count": len(items),
        "Incidents_Count": incident_count,
        "Sector_Unknown_Count": sector_unknown,
        "Sector_Unknown_Pct": f"{_pct(sector_unknown, incident_count):.2f}",
        "Location_Unknown_Count": location_unknown,
        "Location_Unknown_Pct": f"{_pct(location_unknown, incident_count):.2f}",
        "Potential_Duplicate_Pairs": duplicate_pairs,
        "Potential_Duplicate_Rate_Pct": f"{_pct(duplicate_pairs, incident_count):.2f}",
        "Corpus_Cases": corpus["cases"],
        "Corpus_False_Positives": corpus["false_positives"],
        "Corpus_False_Positive_Rate_Pct": f"{corpus['false_positive_rate_pct']:.2f}",
        "Corpus_False_Negatives": corpus["false_negatives"],
        "Corpus_Classification_Errors": corpus["classification_errors"],
        "Dedup_Known_False_Merges": dedup["known_nonduplicate_false_merge_count"],
        "Duration_s": f"{duration_seconds:.1f}",
        "Requests": requests,
        "LLM_Calls": llm_calls,
        "LLM_Cost_USD": f"{llm_cost_usd:.6f}",
    }


def scheduled_reliability(run_log: list[dict]) -> dict:
    observed = [row for row in run_log if row.get("Trigger") == "schedule"][-SCHEDULED_RELIABILITY_WINDOW:]
    successes = sum(row.get("Overall_Status") == "OK" for row in observed)
    consecutive = 0
    for row in reversed(observed):
        if row.get("Overall_Status") != "OK":
            break
        consecutive += 1
    return {
        "observed": len(observed),
        "window": SCHEDULED_RELIABILITY_WINDOW,
        "successes": successes,
        "success_rate_pct": _pct(successes, len(observed)) if observed else None,
        "target_pct": SCHEDULED_SUCCESS_TARGET_PCT,
        "consecutive_successes": consecutive,
        "required_consecutive_successes": REQUIRED_CONSECUTIVE_SCHEDULED_SUCCESSES,
        "seven_run_proof_ready": consecutive >= REQUIRED_CONSECUTIVE_SCHEDULED_SUCCESSES,
    }


def snapshot_payload(run_log: list[dict], run_id: str) -> dict:
    """État déterministe publiable dans status.json (sans horloge courante)."""
    latest: dict[str, object] = next(
        (
            row for row in reversed(store.load_production_metrics())
            if row.get("Run_ID") == run_id and row.get("Published") == "true"
        ),
        {},
    )
    incidents = store.load_incidents()
    sector_unknown = sum(row.Secteur == config.SECTOR_UNKNOWN for row in incidents)
    location_unknown = sum(row.Localisation == config.LOC_INCONNU for row in incidents)
    return {
        "scheduled_reliability": scheduled_reliability(run_log),
        "targets": {
            "freshness_hours": FRESHNESS_TARGET_HOURS,
            "scheduled_success_pct": SCHEDULED_SUCCESS_TARGET_PCT,
            "sector_unknown_pct": SECTOR_UNKNOWN_TARGET_PCT,
            "location_unknown_pct": LOCATION_UNKNOWN_TARGET_PCT,
        },
        "quality": {
            "sector_unknown_pct": _pct(sector_unknown, len(incidents)),
            "location_unknown_pct": _pct(location_unknown, len(incidents)),
            "potential_duplicate_pairs": int(_float(latest.get("Potential_Duplicate_Pairs"))),
            "potential_duplicate_rate_pct": _float(latest.get("Potential_Duplicate_Rate_Pct")),
            "corpus_false_positive_rate_pct": _float(latest.get("Corpus_False_Positive_Rate_Pct")),
            "corpus_false_negatives": int(_float(latest.get("Corpus_False_Negatives"))),
            "corpus_classification_errors": int(_float(latest.get("Corpus_Classification_Errors"))),
            "dedup_known_false_merges": int(_float(latest.get("Dedup_Known_False_Merges"))),
        },
        "performance": {
            "duration_seconds": _float(latest.get("Duration_s")),
            "requests": int(_float(latest.get("Requests"))),
            "llm_calls": int(_float(latest.get("LLM_Calls"))),
            "llm_cost_usd": _float(latest.get("LLM_Cost_USD")),
        },
    }


def health_payload(*, now: dt.datetime | None = None) -> dict:
    now = now or dt.datetime.now(dt.UTC)
    if now.tzinfo is None:
        now = now.replace(tzinfo=dt.UTC)
    snapshot = store.load_snapshot()
    snapshot_at = _parse_datetime(snapshot.get("As_Of", ""))
    exact_age_hours = None if snapshot_at is None else max(
        0.0,
        (now.astimezone(dt.UTC) - snapshot_at.astimezone(dt.UTC)).total_seconds() / 3600,
    )
    freshness_ok = exact_age_hours is not None and exact_age_hours < FRESHNESS_TARGET_HOURS
    age_hours = None if exact_age_hours is None else round(exact_age_hours, 2)

    metrics = store.load_production_metrics()
    latest: dict[str, object] = next(
        (row for row in reversed(metrics) if row.get("Published") == "true"), {}
    )
    reliability = scheduled_reliability(store.load_run_log())
    sector_rows = store.load_sector_resolution()
    inferred_rows = [row for row in sector_rows if row.get("Status") in {"inferred", "inferred_low"}]
    referenced_rows = [row for row in sector_rows if row.get("Status") == "referenced"]
    low_rows = [row for row in sector_rows if row.get("Status") == "inferred_low"]
    reasons: list[str] = []
    if age_hours is None:
        reasons.append("fraîcheur du snapshot inconnue")
    elif not freshness_ok:
        reasons.append(f"snapshot âgé de {age_hours:.1f} h (cible < {FRESHNESS_TARGET_HOURS:.0f} h)")

    incidents = store.load_incidents()
    sector_unknown_pct = _pct(
        sum(row.Secteur == config.SECTOR_UNKNOWN for row in incidents), len(incidents)
    )
    location_unknown_pct = _pct(
        sum(row.Localisation == config.LOC_INCONNU for row in incidents), len(incidents)
    )
    if sector_unknown_pct >= 0 and sector_unknown_pct >= SECTOR_UNKNOWN_TARGET_PCT:
        reasons.append(f"secteur inconnu {sector_unknown_pct:.2f} % (cible < {SECTOR_UNKNOWN_TARGET_PCT:.0f} %)")
    if location_unknown_pct >= 0 and location_unknown_pct >= LOCATION_UNKNOWN_TARGET_PCT:
        reasons.append(f"localisation inconnue {location_unknown_pct:.2f} % (cible < {LOCATION_UNKNOWN_TARGET_PCT:.0f} %)")
    if reliability["observed"] and reliability["success_rate_pct"] < SCHEDULED_SUCCESS_TARGET_PCT:
        reasons.append(
            f"succès planifié {reliability['success_rate_pct']:.2f} % "
            f"(cible ≥ {SCHEDULED_SUCCESS_TARGET_PCT:.0f} %)"
        )

    return {
        "alert": bool(reasons),
        "alert_reasons": reasons,
        "freshness": {
            "snapshot_as_of": snapshot.get("As_Of", ""),
            "age_hours": age_hours,
            "target_hours": FRESHNESS_TARGET_HOURS,
            "ok": freshness_ok,
        },
        "scheduled_reliability": reliability,
        "quality": {
            "sector_unknown_pct": None if sector_unknown_pct < 0 else sector_unknown_pct,
            "sector_unknown_target_pct": SECTOR_UNKNOWN_TARGET_PCT,
            "sector_inferred_items": len(inferred_rows),
            "sector_referenced_items": len(referenced_rows),
            "sector_non_confirmed_items": len(inferred_rows) + len(referenced_rows),
            "sector_low_confidence_items": len(low_rows),
            "location_unknown_pct": None if location_unknown_pct < 0 else location_unknown_pct,
            "location_unknown_target_pct": LOCATION_UNKNOWN_TARGET_PCT,
            "potential_duplicate_pairs": int(_float(latest.get("Potential_Duplicate_Pairs"))),
            "potential_duplicate_rate_pct": _float(latest.get("Potential_Duplicate_Rate_Pct")),
            "corpus_false_positive_rate_pct": _float(latest.get("Corpus_False_Positive_Rate_Pct")),
            "corpus_false_negatives": int(_float(latest.get("Corpus_False_Negatives"))),
            "corpus_classification_errors": int(_float(latest.get("Corpus_Classification_Errors"))),
            "dedup_known_false_merges": int(_float(latest.get("Dedup_Known_False_Merges"))),
        },
        "performance": {
            "duration_seconds": _float(latest.get("Duration_s")),
            "requests": int(_float(latest.get("Requests"))),
            "llm_calls": int(_float(latest.get("LLM_Calls"))),
            "llm_cost_usd": _float(latest.get("LLM_Cost_USD")),
        },
    }


def markdown_report(payload: dict) -> str:
    fresh = payload["freshness"]
    reliability = payload["scheduled_reliability"]
    quality = payload["quality"]
    perf = payload["performance"]
    age = "inconnue" if fresh["age_hours"] is None else f"{fresh['age_hours']:.1f} h"
    scheduled_rate = (
        "n.d."
        if reliability["success_rate_pct"] is None
        else f"{reliability['success_rate_pct']:.2f} %"
    )
    sector_unknown = (
        "n.d."
        if quality["sector_unknown_pct"] is None
        else f"{quality['sector_unknown_pct']:.2f} %"
    )
    location_unknown = (
        "n.d."
        if quality["location_unknown_pct"] is None
        else f"{quality['location_unknown_pct']:.2f} %"
    )
    lines = [
        "## Production — fiabilité quotidienne",
        f"- Fraîcheur : **{age}** (cible < {fresh['target_hours']:.0f} h)",
        f"- Succès planifiés : **{scheduled_rate}** sur {reliability['observed']} run(s) observé(s) (cible ≥ {reliability['target_pct']:.0f} %)",
        f"- Série planifiée : **{reliability['consecutive_successes']}/{reliability['required_consecutive_successes']}** succès consécutifs réels",
        f"- Secteur inconnu : **{sector_unknown}** (cible < {quality['sector_unknown_target_pct']:.0f} %)",
        f"- Localisation inconnue : **{location_unknown}** (cible < {quality['location_unknown_target_pct']:.0f} %)",
        f"- Doublons potentiels : **{quality['potential_duplicate_pairs']}** paire(s), {quality['potential_duplicate_rate_pct']:.2f} paires pour 100 incidents",
        f"- Corpus : faux positifs **{quality['corpus_false_positive_rate_pct']:.2f} %**, faux négatifs **{quality['corpus_false_negatives']}**, erreurs de classement **{quality['corpus_classification_errors']}**",
        f"- Run : **{perf['duration_seconds']:.1f} s**, {perf['requests']} requêtes, {perf['llm_calls']} appels LLM, **${perf['llm_cost_usd']:.6f}**",
    ]
    if payload["alert_reasons"]:
        lines.append("- Alertes : **" + " ; ".join(payload["alert_reasons"]) + "**")
    return "\n".join(lines)
